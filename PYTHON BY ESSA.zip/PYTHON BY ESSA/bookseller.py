from flask import Flask, render_template
from urllib.parse import quote_plus
import datetime

app = Flask(__name__)

WHATSAPP_NUMBER = '923331533250'  # Change this to your number

BOOKS_DATA_RAW = {
    "Self-Improvement": [
        {
            "id": "self001",
            "title": "Atomic Habits",
            "author": "James Clear",
            "price": "PKR 400",
            "image_url": "81https://m.media-amazon.com/images/I/81ANaVZk5LL._SL1500_.jpg"
        },
    ],
    "Business & Finance": [
        {
            "id": "biz001",
            "title": "Rich Dad Poor Dad",
            "author": "Robert Kiyosaki",
            "price": "PKR 400",
            "image_url": "https://m.media-amazon.com/images/I/81bsw6fnUiL.jpg"
        }
    ]
}

def generate_online_image_books_data():
    processed_data = {}
    for category_name, books_list in BOOKS_DATA_RAW.items():
        processed_books = []
        for book_item in books_list:
            book_with_url = book_item.copy()
            book_with_url['cover_url'] = book_item['image_url']
            processed_books.append(book_with_url)
        processed_data[category_name] = processed_books
    return processed_data

@app.route('/')
def home():
    books_for_template = generate_online_image_books_data()
    background_image_url = "https://images.pexels.com/photos/1907784/pexels-photo-1907784.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    return render_template(
        'index.html',
        books_data=books_for_template,
        whatsapp_number=WHATSAPP_NUMBER,
        quote_plus=quote_plus,
        current_year=datetime.datetime.now().year,
        background_image_url=background_image_url
    )

if __name__ == '__main__':
    app.run(debug=True)
